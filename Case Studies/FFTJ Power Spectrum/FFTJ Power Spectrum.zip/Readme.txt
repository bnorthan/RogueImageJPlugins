Automation with FFTJ case study

This illustrates how to automate processing using imageJ

1.  Shows how to run a macro in a loop. 
2.  Shows how to make a non-scriptable plugin scriptable.
